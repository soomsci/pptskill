# 기존 외부 레퍼런스 후보 — v3 보존 자료

> 아래 출처 확인 상태는 **첨부 v3에 기록된 과거 메모**다. v4 개선에서 재검증하지 않았으며 현재 접속·판매·라이선스를 보증하지 않는다. 기본 스타일 선택에는 `art-directions.md`와 새 디자인 아틀라스를 사용한다. 이번 조사 내역은 `research-synthesis.md` 참고.

> 이 파일은 `SKILL.md`의 디자인 의사결정을 위한 **참고 목록**이다. 외부 링크를 실제로 열어볼 수 있을 때는 원본 이미지와 여러 페이지를 관찰한다. 열 수 없을 때에는 아래의 기록만으로 합리적인 기본안을 만들되 **원본을 직접 보고 분석했다고 주장하지 않는다**. 템플릿의 비용·다운로드 가능 여부·라이선스는 제작할 때 확인한다. 외부 디자인의 이미지와 유료 템플릿을 무단 수집·재배포하지 않는다.

## 출처 확인 상태

- Stephen Kelman / RRGraph / Blank Studio: Behance 검색 결과로 프로젝트 제목·작성자 확인. Behance 본문은 접근 환경에 따라 제한될 수 있다.
- Forma 60: 판매자 페이지 확인. 유료 Canva 편집 템플릿이며 페이지 내 장수 표기가 **20 / 23 / 이미지 설명상 24**로 다르므로 정확한 장수를 단정하지 않는다.
- Canva 템플릿: 공식 **카테고리 목록 페이지에서 템플릿명 확인**. 아래 링크는 개별 템플릿 ID가 아니라 탐색 페이지인 경우가 많다.
- HAUS: 이전 조사에 제시된 Behance 링크. 직접 열기 차단 가능. 디자인 특징은 참조 후보이지 모든 내부 슬라이드를 검증했다는 의미가 아니다.

## 기존 오프라인 시각 자료(기능 배치 참고)

- `assets/offline-reference-atlas-preview.png` 및 `assets/offline-reference-atlas.pptx`: R01–R07, C01–C03의 용도별 구조를 보여 주는 **독립적으로 새로 그린 시각 학습자료**. 외부 원본·스크린샷은 포함하지 않으며 원본을 직접 봤다는 증거도 아니다.
- 원본 Behance 403 시 위 자료를 실제로 시각 확인한다. 접근 방법과 검수 기준은 [`offline-reference-guide.md`](offline-reference-guide.md) 참고.

## 가장 중요한 사용 원칙

1. **레퍼런스 전체를 한 장에 섞지 않는다.** 전체 덱의 기초 디자인 문법(primary grammar)은 한 가지로 고정한다.
2. 나머지 참고 자료는 *기능별 해결책*을 빌린다. 예: Stephen Kelman의 그리드가 뼈대, Blank Studio의 단계 번호 및 기술 도식이 실습장, Forma 60의 표 정리가 보고장.
3. 화면의 컬러·서체·기하학적 모티프를 그대로 모방하지 말고 **정보 위계·그리드·컨텐츠 밀도·그림과 설명의 관계**를 추출한다.
4. 실물을 보지 못했으면 `inferred`, 실제로 이미지를 검사했으면 `observed`, 원본을 받았어도 열어보지 못했다면 `provided-uninspected`로 기록한다. 자료 제공 여부와 실제 시각 관찰은 구분한다.
5. 다운로드 가능성과 무료 이용 가능성은 별개다. 라이선스 확인 전에는 참고용으로만 다룬다.

---

## 핵심 7종

### R01 — Stephen Kelman / Highlight Presentation Grid System
- 원본 제작자 포트폴리오(우선): https://stephenkelman.co.uk/highlight-presentation-grid-system-for-indesign
- Behance 보조: https://www.behance.net/gallery/236908777/Highlight-Presentation-Grid-System-for-InDesign
- 제작자 사이트: https://stephenkelman.co.uk/
- **핵심**: 16:9 포맷, 높은 밀도의 모듈형 그리드(36/48 필드), 스타일시트, 텍스트 베이스라인·행간 관리. **템플릿 원본은 InDesign용**이며 PowerPoint 파일이라고 가정하지 않는다.
- 추출할 문법: 동일한 베이스라인, 비율로 나눠진 이미지/문장 폭, 제목과 캡션의 명확한 크기 위계, 여백이 곧 구분자가 되는 구성.
- 적합한 장: 표지, 정의, 2열 비교, 긴 설명을 정리한 도판, 인용·근거.
- **무엇을 복제하지 말까**: 눈에 보이는 사소한 브랜드 요소나 고유한 페이지를 픽셀 단위로 따라 하기.
- 확인 질문: 이 그리드는 콘텐츠의 줄 길이와 위계를 해결하고 있는가, 아니면 빈 칸을 채우려는 것인가?

### R02 — RRGraph Design / 01° Grid Presentation
- Behance 원본(차단 가능): https://www.behance.net/gallery/242218917/01-Grid-Presentation-FREE-DOWNLOAD
- 공개 미리보기 보조 URL(외부 이미지, 차단 가능): https://mir-s3-cdn-cf.behance.net/project_modules/fs/4faeca242218917.69687af9e534d.png
- **핵심**: 전략 보고·긴 문서를 위한 고밀도 그리드; 내용의 양과 유형이 달라도 정렬을 유지하는 유연한 틀. 게시물의 무료 다운로드 문구는 **사용 라이선스의 포괄적 허락이 아니다**.
- 추출할 문법: 작은 정보 라벨, 서체 계층, 정량 정보/설명 문장의 공존, 촘촘한 정보 블록도 읽히는 정렬.
- 적합한 장: 연구 결과, 비교 지표, 보고서, 체계적 요약, 세부 목차.
- 흔한 오용: 사용자 발표에 필요 없는 초고밀도 페이지를 강제로 만드는 것.

### R03 — More By Us / Forma 60 Proposal Deck (Canva)
- 원본: https://morebyus.com/products/proposal-deck-template-canva-editable-forma-60-collection
- **핵심**: 서비스·비용·타임라인·사례 등 성격이 다른 정보를 한 브랜드 시스템 아래 묶는 모노크롬 비즈니스 덱. **상업용 유료 상품**.
- 추출할 문법: 가격 표의 정렬, 범주 간 간격, 일정 단계의 시각적 관계, 유효한 표/숫자에만 강조를 할당.
- 적합한 장: 실습 일정, 연수 계획, 전후 비교표, 역할 분담, 결과표.
- 흔한 오용: 제안서의 빈 'Our Team' 'Mission' 같은 기업용 내용을 교육용 덱에 억지 삽입.

### R04 — Canva / White Modern SOP & Training Manual Deck
- 목록 페이지: https://www.canva.com/templates/s/sop/?continuation=100
- Canva 검색어: `White Modern SOP & Training Manual Deck Presentation`
- **핵심**: 순서·동작·기준을 명료하게 전달하는 매뉴얼형 프레젠테이션 (공식 목록에 12장 템플릿으로 노출).
- 추출할 문법: 한 단계 = 동작 중심 제목, 큰 실제 화면, 좌측 또는 하단의 짧은 사용법, 번호/오류 주석, 넉넉한 화면 캡처 영역.
- 적합한 장: 설치, 설정, 화면 조작, 교사 실습.
- 흔한 오용: 정작 조작해야 하는 화면을 작게 만들고 설명만 늘리는 것.

### R05 — Canva / Almost White and Black Simple Professional Personal Portfolio
- 목록 페이지: https://www.canva.com/presentations/templates/portfolio/
- Canva 검색어: `Almost White and Black Simple Professional Personal Portfolio Presentation`
- **핵심**: 실제 작업 결과 이미지와 짧은 설명의 편집적 조합 (공식 목록에 11장으로 노출).
- 추출할 문법: 이미지의 역할에 따라 과감한 크기 변화, 사례별 캡션 위치 조절, 빈 공간을 부정적으로 보지 않는 사고.
- 적합한 장: 교사가 만든 실제 수업자료, AI 생성 전후, 제품 화면, 사례 분석.
- 흔한 오용: 포트폴리오가 아닌데 큰 이미지 자리를 가짜 스톡 사진으로 채우는 것.

### R06 — HAUS / Brand Strategy – Branding Presentation Fashion
- Behance 원본(차단 가능): https://www.behance.net/gallery/153925167/HAUS-Brand-Strategy-Branding-Presentation-Fashion
- 공개 미리보기 보조 URL(외부 이미지, 차단 가능): https://mir-s3-cdn-cf.behance.net/project_modules/max_3840/3ee1cd153925167.633895b010619.jpg
- **핵심**: 강한 타이포그래피, 이미지 크기 대비, 에디토리얼·패션 룩북 같은 느린 리듬의 도입부를 연구할 후보.
- 추출할 문법: 큰 제목과 여백의 긴장, 섹션 전환, 이미지가 전달하는 실제 주제를 우선하는 표지.
- 적합한 장: 표지, 큰 질문, 섹션 구분, 마지막 한 문장.
- 흔한 오용: 실습·기술 설명 페이지 전체를 패션 포트폴리오처럼 만드는 것.
- 확인 제한: 접근 환경에서 프로젝트 본문이 차단될 수 있으므로 내부 세부 페이지를 확인했다고 주장하지 않는다.

### R07 — Blank Studio / Instruction Manual Design (Orbitvu)
- 원본: https://www.behance.net/gallery/62448869/Instruction-manual-design
- **핵심**: 실제 사진촬영 장비의 조립 매뉴얼 프로젝트. 제작자 설명상 **28개 기술 일러스트**, 흰색·회색·검정·파랑의 네 색으로 구성.
- 추출할 문법: 제품의 위치·연결·순서가 정확한 삽화, 촘촘하지만 분명한 번호 체계, 설명선과 부품 콜아웃.
- 적합한 장: 소프트웨어 조작 흐름, 데이터 흐름도, 서비스 설정 메뉴, 단계적 작업 수행.
- 흔한 오용: 실물을 확인하지 않고 기술 삽화를 사실처럼 생성하는 것. 정확한 UI/구성요소 없으면 삽입 자리표시자를 둔다.

---

## Canva 보조 3종 (이전 후보 5개 중 R04·R05를 제외한 고유 3개)

### C01 — Black And White Minimalist Monochrome Business Proposal Presentation
- 목록: https://www.canva.com/templates/s/formal/
- 검색어: `Black And White Minimalist Monochrome Business Proposal Presentation`
- 역할: 제안/의사결정/결론과 근거. 표·짧은 문장·제약 조건을 지식의 위계로 배치하는 데 참고.
- 주의: 목록에서 발견된 이름이며, 템플릿 세부 슬라이드를 모두 검증했다는 뜻은 아니다.

### C02 — White and Black Modern Company Research Proposal Presentation
- 목록: https://www.canva.com/templates/s/research/
- 검색어: `White and Black Modern Company Research Proposal Presentation`
- 역할: 연구 질문→방법→자료→해석의 흐름. 도표 출처와 본문 텍스트의 균형.
- 주의: 공식 카테고리 목록에서 발견된 이름이며, 구체적인 슬라이드 구성은 실제 확인 필요.

### C03 — Grey Black Minimalist Simple Project Presentation
- 목록: https://www.canva.com/presentations/templates/simple/
- 검색어: `Grey Black Minimalist Simple Project Presentation`
- 역할: 진행 상황·프로젝트 타임라인·간결한 기술 발표. 반드시 기본 슬라이드를 그대로 반복하지는 말 것.
- 주의: 공식 카테고리 목록에서 발견된 이름이며, 세부 템플릿은 실제 열람 뒤 결정.

---

## 슬라이드 목적별 우선 참고

| 슬라이드 목적 | 1순위 | 2순위 | 피해야 할 선택 |
| --- | --- | --- | --- |
| 전체 덱의 정렬과 타이포그래피 | R01 | R02 | 페이지별로 서로 다른 축 사용 |
| 표지 / 장 구분 | R06 | R01 | 의미 없는 로봇·추상 이미지 |
| 개념 설명 | R01 | R07 | 전구/기어 아이콘 3개 배치 |
| 두 입장 / 두 방식 비교 | R02 | R03 | 차이가 없는 3개 카드 |
| 통계·데이터·사업 보고 | R02 | C02/R03 | 임의의 수치와 비율 |
| 소프트웨어 사용법 | R04 | R07 | AI가 만들어낸 가짜 UI |
| 실제 성과/작업 사례 | R05 | R03 | 스톡 이미지로 성과 대신하기 |
| 프로세스·연결 구조 | R07 | R04 | 연결 의미가 없는 화살표 |
| 연구 발표 | C02 | R02 | 출처 없는 인포그래픽 |
| 실습·프로젝트 발표 | R04 | C03 | 분위기만 비슷한 장식 |
| 보고·요청·결정 | C01 | R03 | 컨설팅용 말만 큰 정리 |

## 레퍼런스 채택 절차 (필수)

1. **슬라이드 목적을 1문장으로 쓴다.** '예쁜 페이지'는 목적이 아니다.
2. 위 표에서 1순위 후보를 골라 원본의 **실제 이미지/페이지가 보이면 확인**한다.
3. 다음 6개 항목을 기록한다: `정렬축 / 공간 비율 / 글자 단계 / 정보 밀도 / 이미지 위치 / 반복 요소`.
4. 레퍼런스를 복제하지 말고 **재현 가능한 배치 규칙**으로 바꾼다. 예: '화면 68%, 지시 24%, 간격 8%'와 같이 대략적 비율을 사용한다.
5. 제작·렌더링 후 다음을 비교한다: **시각적 리듬**이 비슷한가? 정보 목적이 더 명료해졌는가? 작위적인 UI 카드가 추가됐는가?
6. 부족하면 카드·색상을 바꾸는 미세 조정보다 **레이아웃 재구성**을 우선한다.

## 실제 제작 시 권리 원칙

- 이 패키지에는 외부 유료 템플릿의 원본 파일, 스크린샷, 사진, 브랜드 요소를 무단 포함하지 않았다.
- `assets/editorial-layout-library.pptx`는 위 디자인의 **일반적 편집 원리**를 토대로 독립적으로 제작한 자체 예시 슬라이드이다. 외부 템플릿의 재배포판이 아니다.
- 원본을 구매/다운로드한다면 이용약관에 맞게 사용하고, 필요시 원저작자를 표기한다.
