# 오프라인 시각 자료와 접근 실패 대응

## v4.2 권장 자료

- [사용자 지정 디자인](preferred-design.md)을 먼저 읽는다. 원본 PPTX와 기본 예제 D를 우선하고 다른 아틀라스는 대안 비교용으로 사용한다.
- [design-atlas.html](../assets/design-atlas.html): 12개 방향을 비교하는 로컬 HTML. 네트워크·외부 폰트 없이 열 수 있다. 각 예시를 눌러 확대한다. 글꼴은 시스템에 따라 달라질 수 있다.
- [design-atlas-preview.png](../assets/design-atlas-preview.png): 위 HTML의 전체 미리보기. 실제로 열어서 관찰한다.
- 사진 중심 D03·D09는 CC0 실제 사진을 사용한다. 장소·촬영자·사용 조건은 [사진 출처](../assets/photos/SOURCES.md)에 기록했다. 가상 운영안의 현장 사진으로 해석하지 않는다.
- [4개 미니 덱](deck-study-guide.md)은 같은 원고로 만든 편집 가능한 4장짜리 PPTX와 렌더 미리보기를 포함한다.
- 운영안 예시의 문장·수치·인용은 모두 가상이다. 실제 발표 자료의 근거로 재사용하지 않는다.

## 기존 자료의 역할

[offline-reference-atlas.pptx](../assets/offline-reference-atlas.pptx)와 [editorial-layout-library.pptx](../assets/editorial-layout-library.pptx), 각각의 PNG는 v3에서 보존한 편집 객체·기능별 배치 자료다. 흰 배경·공통 제목 등의 스타일을 매번 기본값으로 상속하지 않는다. R01 등의 코드는 외부 원작을 실제로 복제했다는 의미가 아니다.

## 읽기 실패 시

1. HTML을 열 수 없으면 PNG를 본다.
2. PNG도 볼 수 없으면 사용 가능한 도구로 HTML 또는 기존 PPTX를 렌더링한다.
3. 어떤 시각 도구도 없으면 문서의 선택 기준으로 진행하되 시각 관찰·렌더 검수는 미수행으로 남긴다.
4. 외부 페이지가 403·로그인 제한·오류를 반환하면 같은 주소를 반복 요청하지 않는다. 접근 가능한 공식 대안이나 로컬 자료를 사용한다.

관찰 상태와 사용 권한은 별개다. 원작 텍스트만 읽었거나 로컬 예시만 봤다면 그렇게 기록한다. 내부 상태 기록은 사용자가 원하거나 결과의 한계에 영향을 줄 때만 전달한다.
