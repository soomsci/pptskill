# 웹 조사와 적용 판단

조사일: 2026-10-09 (Asia/Seoul). 아래는 이번 개선에서 확인한 20개 공개 자료와 적용 위치다. 인터넷의 모든 팁을 수집했다는 의미는 아니다. 검색 결과 수를 적용 원칙 수로 세지 않았고, 같은 조언을 중복해서 규칙으로 만들지 않았다. 출처의 전문·이미지·유료 템플릿을 복제하지 않고 짧게 요약했다.

상태 `본문 확인`은 도구로 문서 텍스트를 확인했다는 뜻이다. 외부 디자인 이미지를 모두 시각 검수했다는 뜻은 아니다. 스킬의 12개 스타일과 24개 구도는 아래 자료들을 참고한 자체 종합이며, 각 출처가 이 분류를 제시한 것은 아니다.

## 읽은 자료와 반영 위치

| ID | 자료 | 확인/핵심 요지 | 적용 위치와 조건 |
|---|---|---|---|
| S01 | [Duarte — 발표 슬라이드와 Slidedoc](https://www.duarte.com/blog/the-slides-you-deliver-versus-the-slidedoc-you-leave-behind/) | 본문 확인. 투사 발표와 독립적으로 읽는 문서는 설명량이 다름 | storyboard-patterns: 매체 분기. 별도 덱 자동 추가는 하지 않음 |
| S02 | [Assertion–Evidence — Tutorial](https://www.assertion-evidence.org/tutorial.html) | 본문 확인. 메시지에 시각적 근거를 연결 | copy-and-korean: 근거가 있는 결과 장에 적용, 모든 제목의 주장화는 제외 |
| S03 | [NN/g — Visual Design Principles](https://www.nngroup.com/articles/principles-visual-design/) | 본문 확인. 크기·위계·균형·대비·그룹화 | visual-system: 정렬·근접성·초점. UI의 권장 개수를 보편 법칙으로 삼지 않음 |
| S04 | [IBM — Layout tips](https://www.ibm.com/design/language/layout/tips-and-techniques/) | 본문 확인. 반복과 변화의 균형, 여백, 비대칭 | art-directions / quality-gates: 일관성 있는 변화. IBM 그리드 강제 안 함 |
| S05 | [IBM — Photography tips](https://www.ibm.com/design/language/photography/tips-and-techniques/) | 본문 확인. 초점·크롭·맥락 있는 이미지 | media-direction: 구체적인 피사체. 특정 촬영 시점·필터 금지는 브랜드 한정 |
| S06 | [Google Design — Choosing Web Fonts](https://design.google/library/choosing-web-fonts-beginners-guide) | 본문 확인. 용도·길이·언어 지원에 맞는 서체 | visual-system: 제목/본문 역할과 한글 혼용. 웹 폰트 사용성을 PPT로 단정하지 않음 |
| S07 | [Butterick — Line length](https://practicaltypography.com/line-length.html) | 본문 확인. 읽기 편한 행 길이를 고려 | copy-and-korean: 한글과 투사 화면에 영어 글자 수 기준을 그대로 적용하지 않음 |
| S08 | [Butterick — Summary of key rules](https://practicaltypography.com/summary-of-key-rules.html) | 본문 확인. 글자 크기·행간·행 길이·서체의 결합 | visual-system: 글자 크기만 조정하지 않는 편집 |
| S09 | [W3C — Korean Layout Requirements](https://www.w3.org/TR/klreq/) | 본문 확인. 줄 나눔, 금칙, 섞어짜기. Group Note Draft | copy-and-korean: 한국어 조판 점검. 완성된 규범 또는 특정 PPT 구현 보증으로 인용하지 않음 |
| S10 | [Datawrapper — Text in data visualizations](https://www.datawrapper.de/blog/text-in-data-visualizations) | 본문 확인. 직접 라벨·단위·주석을 자료 가까이에 | composition-recipes: 불필요한 시선 이동 줄이기 |
| S11 | [Datawrapper — Beautiful colors](https://www.datawrapper.de/blog/beautifulcolors) | 본문 확인. 채도·명도·색 조합을 함께 조정 | visual-system: 원색·중간색 금지 대신 관계와 읽힘 확인 |
| S12 | [Datawrapper — Which color scale](https://www.datawrapper.de/blog/which-color-scale-to-use-in-data-vis) | 본문 확인. 데이터 성격에 맞는 색척도 | visual-system: 범주/연속/발산을 구분 |
| S13 | [Datawrapper — Zero baseline](https://www.datawrapper.de/academy/why-our-column-and-bar-charts-start-at-zero) | 본문 확인. 막대의 길이 해석과 기준선 | composition-recipes: 0 기준 막대, 필요하면 점·선으로 전환 |
| S14 | [Storytelling with Data — Declutter](https://www.storytellingwithdata.com/blog/2016/3/1/declutter-your-data-visualizations) | 본문 확인. 불필요한 시각 부하 정리 | composition-recipes: 장식 정리와 필수 정보 보존을 함께 판단 |
| S15 | [W3C — Contrast Minimum](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum) | 본문 확인. 일반/큰 텍스트의 대비 기준 | visual-system: 실무 점검값으로 참고. 프로젝터 가독성 보증 아님 |
| S16 | [Microsoft — Accessible PowerPoint](https://support.microsoft.com/en-us/accessibility/powerpoint/make-your-powerpoint-presentations-accessible-to-people-with-disabilities) | 본문 확인. 대체 텍스트·색 외의 정보 전달·읽기 순서 | quality-gates: 도구가 지원하는 접근성 점검 |
| S17 | [Microsoft — Reading Order pane](https://support.microsoft.com/en-us/powerpoint/make-slides-easier-to-read-by-using-the-reading-order-pane) | 본문 확인. 객체 읽기 순서·대체 텍스트 | quality-gates: 시각 순서와 별도 확인, 버전별 차이 고려 |
| S18 | [Microsoft — Font embedding](https://support.microsoft.com/en-us/office/fonts/benefits-of-embedding-custom-fonts) | 본문 확인. 폰트 대체, 부분 임베딩의 편집 제약 | visual-system: 도구·권한·대체 서체 확인 |
| S19 | [GOV.UK — Layout](https://design-system.service.gov.uk/styles/layout/) | 본문 확인. 그리드와 긴 문장의 읽기 폭 | D12 / visual-system: 정보 전달 원리 참고. 웹 반응형·글자 수를 슬라이드 규격으로 강제하지 않음 |
| S20 | [NN/g — Progressive disclosure](https://www.nngroup.com/articles/progressive-disclosure/) | 본문 확인. 우선 정보와 후속 세부 정보 구분 | storyboard-patterns: 발표의 단계적 설명에 응용. 필수 조건을 숨기는 데 사용하지 않음 |

## 충돌하는 팁의 해결

| 팁 A | 팁 B | 이 스킬의 선택 |
|---|---|---|
| 한 장 한 메시지 | 복잡한 근거를 보존 | 하나의 논점에 여러 근거 가능. 요청된 자료는 보존 |
| 주장형 제목 | 간단한 주제명 | 증거 장은 관찰/결론, 배경·정의·절차는 정확한 주제명 |
| 모든 장을 다르게 | 반복으로 일관성 | 같은 학습·비교 과제는 반복, 다른 정보 관계는 적합한 구조 |
| 최대한 비워라 | 읽기용은 설명 필요 | 매체·청중 기준으로 밀도 결정 |
| 폰트는 하나 | 개성 있는 타이포그래피 | 역할·언어 지원·호환을 기준으로 체계 선택 |
| 사진은 언제나 필요 | 증거가 없으면 넣지 말라 | 역할이 있을 때 사용. 생성 분위기와 실제 증거 구분 |
| 그라데이션·카드 금지 | 브랜드가 요구 | 사용자·브랜드·정보 기능 우선 |
| 차트는 장식 없이 | 강조하면 이해가 쉬움 | 의미 없는 장식은 덜고 중요한 구간·주석은 유지 |
| 글자 수 제한 | 한국어·공간 차이 | 실제 줄바꿈·시청 거리로 검수 |
| 애니메이션으로 단계 공개 | PDF에서는 사라짐 | 정적 산출물도 이해되게 설계 |

## 채택하지 않은 보편화

- 6×6, 7×7, 10/20/30 등의 숫자 공식을 모든 자료에 강제.
- 무조건 검정·흰색, 무조건 대문자, 무조건 영문 부제, 무조건 왼쪽 정렬.
- 한 덱에 레이아웃을 일정 수 이상 써야 한다는 다양성 할당량.
- 불규칙한 간격·가짜 손글씨·의도적인 오류로 인간의 작업을 흉내 내기.
- 'AI 판별 불가'를 보증하거나 객관적 측정 없이 AI 느낌 점수 발표.

위 항목은 이번 종합에서 제외한 관행이며 특정 출처에 모두 귀속시키지 않는다.

## 접근 제한과 보존 자료

Presentation Zen의 챕터 PDF와 블로그 후보 페이지는 직접 열기에서 오류가 발생했다. 검색 발췌를 읽은 것 이상으로 열람했다고 기록하지 않았고 본문 확인 20개 목록에는 넣지 않았다. v3의 Behance/Canva 링크는 [기존 목록](reference-library.md)에 보존했지만 이번 작업에서 재검증하지 않았다. 외부 링크의 현재 접속·가격·사용 권한은 실제 이용 시 다시 확인한다.
