# 사진 출처와 사용 범위

확인일: 2026-10-09. 아래 두 파일은 개별 원본 설명 페이지에서 CC0 1.0을 확인한 실제 사진이다. Wikimedia 사이트의 일반 이용약관을 사진의 라이선스로 오인하지 않았다.

| 로컬 파일 | 실제 장소 / 촬영자 | 원본 설명 페이지 | 원본 촬영일 | 사용 조건 |
|---|---|---|---|---|
| `jefferson-interior.jpg` | 미국 의회도서관 Thomas Jefferson Building 내부 / MallardTV | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Thomas_Jefferson_Library_of_Congress_Building_interior.jpg) | 2024-03-26 | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |
| `hearst-library.jpg` | Hearst Castle, Casa Grande 도서실 / Daderot | [Wikimedia Commons](https://commons.wikimedia.org/wiki/File:Library_-_Hearst_Castle_-_DSC06817.JPG) | 2013-11-17 | [CC0 1.0](https://creativecommons.org/publicdomain/zero/1.0/) |

배포한 사진 파일은 Commons가 제공하는 각각 960px, 1280px 미리보기 JPEG다. 원본의 색·장소·피사체를 변경하지 않았다. HTML/PPTX에서는 프레임 비율에 맞춰 비파괴 크롭한다. 실제 촬영 장면의 장소와 구도를 익히는 자료이며, 가상 동네 도서관 운영안의 실제 현장이나 이용 실적을 보여주는 증거가 아니다.

슬라이드에는 장소·촬영자·CC0를 표시하고, 전체 URL과 맥락은 발표자 노트에 기록했다. 스킬을 복사할 때 이 파일도 함께 보존한다.
