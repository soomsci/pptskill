# Human-Crafted Slides v3 — Offline-First PPT Skill

Behance 등 디자인 사이트가 403을 반환해도 **로컬 시각 예시를 직접 검사해** 제작을 이어갈 수 있도록 개선한 PPT용 Agent Skill이다. 외부 원작의 스크린샷은 포함하지 않는다.

## 구성

- `SKILL.md`: 핵심 지침, 접속 실패 대응, 작업 순서
- `assets/offline-reference-atlas-preview.png`: 10가지 용도별 **독립 제작** 디자인 배치 예시 시트
- `assets/offline-reference-atlas.pptx`: 위 디자인 예시 10장을 개별 편집 가능한 PPTX로 제공
- `assets/editorial-layout-library.pptx`: 기존 교사 연수 예시 13장
- `assets/editorial-layout-library-preview.png`: 기존 13장 미리보기
- `references/offline-reference-guide.md`: 접근성/관찰 상태 보고 기준
- `references/reference-library.md`: 외부 디자이너·Canva 프로젝트 10종과 URL/역할
- `references/reference-workflow.md`: 관찰→표본→검수
- 나머지 디자인 시스템·스토리보드·QA 문서 유지

**사용법:** `~/.codex/skills/human-crafted-slides/`에 폴더째 설치한 후 스킬 이름을 호출한다. 웹에서 원작을 못 열어도 로컬 이미지와 PPTX를 확인하고 사용할 수 있다.

> `$human-crafted-slides`로 PPT를 만들어줘. 외부 Behance 링크는 필수가 아니다. 스킬 안의 `assets/offline-reference-atlas-preview.png`와 편집 가능한 PPTX 표본을 먼저 열어보면서 레이아웃을 선택하고, 원작 열람 여부와 로컬 자료 관찰 여부를 구분해 보고해줘.

## 출처 및 권리

외부 유료 템플릿, 원작 이미지, 스크린샷은 이 패키지에 포함하지 않았다. 링크 및 디자인 일반 원리를 안내하며, 오프라인 시각 예시는 독립 제작된 교육용 레이아웃이다. 원작을 확인할 수 있는 경우에는 제작자의 웹사이트 또는 정식 구매/라이선스 경로를 이용한다.
